import React,{Component} from 'react';
import ViewCustomer from './view-customer';


class AddCustomer extends Component{

    constructor(){
        super();
        this.state ={data:[]}
    }
    addCustomer =()=>{

        var name = this.refs.name.value;
        var email = this.refs.email.value;
        var cust = this.state.data;
        cust.push({name:name,email:email});

        this.setState({data:cust});


    }
    render(){
        return(<div>

            {/* Send data from parent to child      */}
            <ViewCustomer  customer={this.state.data}/>
            <div>
                    <p> Name <input type="text" ref="name"/> </p>
                    <p> Email <input type="text" ref="email"/> </p>
                    <p> <input type="button" value="Add Customer" onClick={this.addCustomer}  /></p>

            </div>


            </div>)
    }

}

export default AddCustomer;
