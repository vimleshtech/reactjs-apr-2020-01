import React,{Component} from 'react';

class ViewCustomer extends Component{

    constructor(){
        super();
    }
    render(){
        return(<div>

            {this.props.customer.map((r,i)=><p> 

                        {r.name} | {r.email}

            </p>)}
            
            </div>)
    }

}
export default ViewCustomer;
