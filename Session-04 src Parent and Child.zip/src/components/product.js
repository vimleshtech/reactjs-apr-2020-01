import React from 'react';

class Product extends React.Component{

    //constructor is functino which invoke automatically when complement will load
    constructor(){ //constructor is reserved name 
            super(); //call to parenet class constructo r

            this.state ={
                data:[],
                ind:-1
            }

    }

    addProduct= ()=>{
            //alert('hey, you have clicked on button');

            var pname = this.refs.pname.value;
            var price = this.refs.price.value;
            var qty = this.refs.qty.value;

            console.log(pname,price,qty);

            //read existing state 
            var prods = this.state.data;
            //push /add new value 
            prods.push({pname:pname,price:price,qty:qty,isselected:false});
            //update state
            this.setState({data:prods});         

            console.log(prods);

            this.clr();

    }

    delProduct=(ind)=>{

        var prods = this.state.data;
        prods.splice(ind,1);
        this.setState({data:prods});

    }
    editProduct=(ind)=>{
        
        var prods = this.state.data[ind];
        
        this.refs.pname.value=prods.pname;
        this.refs.price.value=prods.price;
        this.refs.qty.value=prods.qty;

        this.setState({ind:ind});


    }
    upProduct=()=>{
        var pname = this.refs.pname.value;
        var price = this.refs.price.value;
        var qty = this.refs.qty.value;

        var ind = this.state.ind;
        var prods = this.state.data;

        prods[ind].pname= pname;
        prods[ind].price= price;
        prods[ind].qty= qty;

        this.setState({data:prods,ind:-1});


    }
    rowSelect=(i)=>{
        console.log('selected row is',i);
        var prods = this.state.data;
        prods[i].isselected= !prods[i].isselected; //true to false | fasle to true 
        
        this.setState({data:prods});

    }
    delSelected=()=>{

        console.log(this.state.data);

        var prods = this.state.data;
        prods = prods.filter(row => row.isselected==false); //get all unselected rows

        this.setState({data:prods}); //update the state with unseleted rows 

    }
    clr=()=>{
                //reset the value 
                this.refs.pname.value="";
                this.refs.price.value="";
                this.refs.qty.value="";
    }
    render(){
        return(<div>
                    <h3>  Product Form  </h3>

                    <p>
                        <input type="text" ref="pname" placeholder="enter product name" class="form-control" />
                    </p>
                    <p>
                    <input type="text" ref="price" placeholder="enter product price" class="form-control" />
                    </p>
                    
                    <p>
                    <input type="text" ref="qty" placeholder="enter product quantity" class="form-control" />
                    </p>
                    
                    <p>
                        <input type="button" onClick={this.clr}  value="Clear" class="btn btn-danger" />
                        <input type="button" onClick={this.addProduct} value="Add Product" class="btn btn-success" />
                        <input type="button" onClick={this.upProduct} value="Update Product" class="btn btn-success" />
                        <input type="button" onClick={this.delSelected} value="Delete Selected" class="btn btn-danger" />

                        

                    </p>

                    <div>
                        <h2> Product List </h2>
                        {this.state.data.map((a,i)=><p >


                            {/* tinary operator  */}
                            {a.isselected?  
                            <input type="checkbox"  checked onClick={()=>this.rowSelect(i)} /> :
                            <input type="checkbox"  unchecked onClick={()=>this.rowSelect(i)} />
                            }    
                            

                                {a.pname} |  {a.price}  | {a.qty} 
                                <input type="button" onClick={()=>this.editProduct(i)}
                                value="edit" />
                                <input type="button" onClick={()=>this.delProduct(i)} value="del" />

                            </p>)}
                    </div>

                    
            </div>)
}

}

export default Product;