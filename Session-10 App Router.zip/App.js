import React,{Component} from 'react';
import ViewProduct from './view-product';
import ProductSummary from './product-summary';
import ApiCall from './api-call';


import {BrowserRouter as Router, Link, Route, Switch} from 'react-router-dom';


import './App.css';

class App extends Component{

  constructor(){

    console.log('component is about to initialize.');
    super();
    this.state ={
        data:[],
        total_count:0,
        selected_count:0,
        unselected_count:0
    }
  }


  componentWillMount(){
    console.log('now, complement will create, means render function will call ');
  }
  componentDidMount(){
    console.log('now, component is created ... ');
  }
  
  componentWillUnmount(){

      console.log('all set...... application is rendered properly ');
  }

  productAdd=()=>{

    var pname = this.refs.pname.value;
    var price = this.refs.price.value;
    var qty = this.refs.qty.value;


    //add data in state object
    var data = this.state.data;
    data.push({pname:pname,price:price,qty:qty,isSelected:false});
    //store the data to state
    this.setState({data:data});


    //reset value / clean the form
    this.refs.pname.value="";
    this.refs.price.value="";
    this.refs.qty.value="";


    //print the data 
    console.log(this.state.data);
    this.summary();
  }

  delRow=(ind) =>{
    //alert(ind);

    var data = this.state.data;
    data.splice(ind,1); //remove the row 

    this.setState({data:data});

  }

  editRow=(ind) =>{
    //alert(ind);

    var data = this.state.data;
   
    this.refs.pname.value=data[ind].pname;
    this.refs.price.value=data[ind].price;
    this.refs.qty.value=data[ind].qty;

    //store index in state
    this.setState({ind});

  }
  upProduct=()=>{

    var ind  = this.state.ind;
    var data = this.state.data;

    var pname = this.refs.pname.value;
    var price = this.refs.price.value;
    var qty = this.refs.qty.value;



    data[ind].pname = pname;
    data[ind].price=price;
    data[ind].qty =qty;

    this.setState({data:data});


    //reset value / clean the form
    this.refs.pname.value="";
    this.refs.price.value="";
    this.refs.qty.value="";


  }
  rmRow=(i)=>{

      alert(i);
  }

  summary=()=>{


      var count = this.state.data.length; //total count
      var unselected = this.state.data.filter(row=> row.isSelected==false).length; //unselected count
      var selected = count - unselected;

      this.setState({
        total_count:count,
        selected_count:selected,
        unselected_count:unselected
      });

  }

  saveData=()=>{

      var name = this.refs.pname.value;
      var email = this.refs.price.value;
      var pwd = this.refs.qty.value;

      //call to api 
      fetch("http://localhost:3010/save-data?name="+name+"&email="+email+"&pwd="+pwd)
      .then(res=>res.json())
      .then(out=>console.log(out));

      alert('data is saved...');

      //clear form 
      this.refs.pname.value="";
      this.refs.price.value ="";
      this.refs.qty.value="";

  }
  render(){

    console.log('now, htmml about to create and send back to page in DOM object ');

    return(

      <div>

            <div className="hd">
                Sales Applicaiton 
            </div>

            
            

            <Router>

            <div className="lft">

              <p className="mn">    <Link to="/">Add Product</Link>  </p>
              <p className="mn">  <Link to="/manage-product">Manage Product</Link>  </p>
              <p className="mn">  <Link to="/add-category" >  Add Category </Link> </p>
              <p className="mn">  <Link to="/manage-category"> Manage Category </Link> </p>
              <p className="mn"> <Link  to="/manage-stock"> Manage Stock </Link> </p>
              <p className="mn">  <Link to="/dashboard"> Dashboard  </Link> </p>

            </div>



            <div className="rht">

              <Switch>
                  <Route path="/manage-product"> 
                          <ApiCall/> 
                  </Route>
                  <Route path="/add-category"> 
                          {/* <ApiCall/>  */}
                          <h2> add category  </h2>
                  </Route>

                  <Route path="/manage-category"> 
                        <h2> manage  category  </h2>
                  </Route>


              </Switch>


             {/*

                      <h1> Product Form </h1>
                        <p>
                            <input placeholder="Product Name" type="text" ref="pname" className="form-control" />
                        </p>
                        <p>
                          <input placeholder="Product Price" type="text" ref="price" className="form-control"/>
                          </p>
                        <p>
                          <input placeholder="Product Quantity" type="text" ref="qty" className="form-control"/>
                        </p>
                      <p>
                        <input type="button" className="btn btn-success" value="Add Product" onClick={this.productAdd} />
                        <input type="button"  className="btn btn-primary" value="Update Product" onClick={this.upProduct} />
                        <input type="button" className="btn btn-danger" value="Save to File" onClick={this.saveData} />

                      </p>

                          <div>
                            <table className="table table-hover">
                              <tr>
                              <td>
                                  Product Name 
                                </td>
                                <td>
                                  Product Price 
                                </td>
                                <td>
                                  Product Quantity 
                                </td>
                                <td>
                                  Action 
                                </td>
                              </tr>

                            
                            
                              {this.state.data.map((row,i)=><tr>
                                
                                  <td>
                                  {row.pname}

                                    </td>
                                    <td>
                                    {row.price}
                                    </td>
                                  <td>

                                      {row.qty} 
                                  </td>
                                  <td>

                                      <input type="button" className="btn btn-danger" value="Del" onClick={()=> this.delRow(i)} />

                                      <input type="button" className="btn btn-success" value="Edit"  onClick={()=>this.editRow(i)}/>
                                  </td>
                                </tr>)}

                                </table>


                          </div>

                        */}

          </div> 
          </Router>

            <div className="clr"> </div>                                  
          <div className="ft">
                      All copy rights reserved @.....
                    </div>
        </div>

    );


    
  }

}

export default App;
