import React from 'react';
import Header from './components/header';
import Footer from './components/footer';
import Product from './components/product';


class App extends React.Component{

  constructor(){
    super();

  }

  render(){

    return(<div>
          <h1> Hey, this is my firt application  </h1>

          <p>
          Interpolation {4+556763}
          </p>

        <Header/>
        <Product/>
        <Footer/>
      
      </div>)
  }


}

export default App;

