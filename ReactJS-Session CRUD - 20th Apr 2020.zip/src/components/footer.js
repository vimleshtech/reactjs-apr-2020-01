import React from 'react';

class Footer extends React.Component{


render(){
        return(<div>
                    <h3>  footer  </h3>
            </div>)
}

}

export default Footer;