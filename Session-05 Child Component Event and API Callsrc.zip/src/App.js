import React,{Component} from 'react';
import ViewProduct from './view-product';
import ProductSummary from './product-summary';
import ApiCall from './api-call';

class App extends Component{

  constructor(){
    super();
    this.state ={
        data:[],
        total_count:0,
        selected_count:0,
        unselected_count:0
    }
  }


  productAdd=()=>{

    var pname = this.refs.pname.value;
    var price = this.refs.price.value;
    var qty = this.refs.qty.value;


    //add data in state object
    var data = this.state.data;
    data.push({pname:pname,price:price,qty:qty,isSelected:false});
    //store the data to state
    this.setState({data:data});


    //reset value / clean the form
    this.refs.pname.value="";
    this.refs.price.value="";
    this.refs.qty.value="";


    //print the data 
    console.log(this.state.data);
    this.summary();
  }

  rmRow=(i)=>{

      alert(i);
  }

  summary=()=>{


      var count = this.state.data.length; //total count
      var unselected = this.state.data.filter(row=> row.isSelected==false).length; //unselected count
      var selected = count - unselected;

      this.setState({
        total_count:count,
        selected_count:selected,
        unselected_count:unselected
      });

  }
  render(){

    return(

      <div>
            <ApiCall/>
            <h1> Product Form </h1>
            <p>
              Product Name  <input type="text" ref="pname" />
            </p>
            <p>
              Price <input type="text" ref="price"/>
              </p>
            <p>
              Quantity <input type="text" ref="qty" />
            </p>
          <p>
            <input type="button" value="Add Product" onClick={this.productAdd} />
          </p>

          <ProductSummary total_count={this.state.total_count}
        selected_count={this.state.selected_count}
        unselected_count={this.state.unselected_count} />


          <div>
              {this.state.data.map((row,i)=>
              <ViewProduct row={row} rmRow={this.rmRow} i={i} />
              
              )}
          </div>


      </div>

    );


    
  }

}

export default App;
