import React,{Component} from 'react';


class ViewProduct extends Component{

  constructor(){
    super();
  }


  render(){

    return(<div>
        
        <div >

                    {this.props.row.pname} | {this.props.row.price} | {this.props.row.qty} 
                    <input type="button" value="Del" onClick={()=>this.props.rmRow(this.props.i)} />
                    <input type="button" value="Edit" />
                    
               </div>

        </div>)
  }
}

export default ViewProduct;