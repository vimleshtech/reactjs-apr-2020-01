import React,{Component} from 'react';

/*
API: library or service which can be accessed over the internet to post or get data 
====================================================================================
Promise : is javascript library to consume the API

	fetch(url)
	.then(res...)
	.then(...)
https://jsonplaceholder.typicode.com/
				todos
				users
				posts		
fetch("https://jsonplaceholder.typicode.com/todos")
.then(res=>res.json())
.then(out=>console.log(out))
*/


class ApiCall extends Component{


    constructor(){
        super();
        this.state ={data:[]};


    }

    getData =()=>{

        fetch("https://jsonplaceholder.typicode.com/todos")
        .then(res=>res.json())
        .then(out=>{

            this.setState({data:out})
        });
    }

    render(){

            return(<div>

                    <input type="button" value="API CALL" onClick={this.getData} />
                    
                        {this.state.data.map((row,i)=><p>
                                    {row.id} | {row.title} 
                            </p>)}
                </div>)
    }

}

export default ApiCall;