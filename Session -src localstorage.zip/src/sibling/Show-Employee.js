import React,{Component} from 'react';



class ShowEmployee extends Component{

    constructor(){
        super();
        this.state ={ name:''}
    }

    receiver=()=>{

        
        var  name = localStorage.getItem('name');
        this.setState({name});


    }

    render(){

        return(<div>
                <h1>
                        Show Employee Component     
                </h1>
                <p>
                    
                    <input type="button" value="Get Employee" onClick={this.receiver} />
                </p>
                <p>
                    Employee data from sibling : {this.state.name}
                </p>

            </div>)
    }

}


export default ShowEmployee;