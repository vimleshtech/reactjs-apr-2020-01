import React,{Component} from 'react';



class Employee extends Component{

    constructor(){
        super();
    }

    handler=()=>{

        var data = this.refs.txt.value;
        localStorage.setItem('name',data);
    }

    render(){

        return(<div>
                <h1>
                        Employee Component     
                </h1>
                <p>
                    Employe Name : <input type="text" ref="txt" />
                    <input type="button" value="Add Employee" onClick={this.handler} />
                </p>

            </div>)
    }

}


export default Employee;