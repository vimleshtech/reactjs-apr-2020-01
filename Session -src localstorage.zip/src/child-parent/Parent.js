import React,{Component} from 'react';

import Child from './Child';

class Parent extends Component{

    constructor(){
        super();
        this.state ={ data:''}
    }

    receiver=()=>{

        var data =localStorage.getItem('data');
        this.setState({data});
        


    }
    render(){

        return(<div>
                    <h1>
                            Parent Compoenent
                    </h1>
                    <p>
                      
                         <input type="button" onClick={this.receiver} value="View Data" />
                    </p>
                    <p>
                        Data from child { this.state.data }
                    </p>

                    <Child/>

            
            </div>);
    }

}

export default Parent;