import React,{Component} from 'react';

class Child extends Component{

    constructor(){
        super();

    }

    handler=()=>{
        
        var data = this.refs.txt.value;
        localStorage.setItem('data',data);
        
        


    }
    render(){

        return(<div>
                    <h1>
                            Child Compoenent
                    </h1>
                    <p>
                        <input type="text" ref="txt"  />
                        <input type="button" value="Save Data" onClick={this.handler} />
                    </p>
                   

            
            </div>);
    }

}

export default Child;