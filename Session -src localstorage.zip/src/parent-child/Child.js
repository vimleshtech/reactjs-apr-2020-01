import React,{Component} from 'react';

class Child extends Component{

    constructor(){
        super();

        this.state={
            data:''
        }
    }

    receiver=()=>{
        
        var data = localStorage.getItem("data");     
        //this.setState({data:data});
        this.setState({data});

    }
    render(){

        return(<div>
                    <h1>
                            Child Compoenent
                    </h1>
                    <p>
                        <input type="button" value="Show Data" onClick={this.receiver} />
                    </p>
                    <p>
                           Data from Parent Component : {this.state.data} 
                    </p>

            
            </div>);
    }

}

export default Child;