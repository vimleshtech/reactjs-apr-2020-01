import React,{Component} from 'react';

import Child from './Child';

class Parent extends Component{

    constructor(){
        super();
    }

    handler=()=>{

        var data = this.refs.txt.value;
        localStorage.setItem("data",data);


    }
    render(){

        return(<div>
                    <h1>
                            Parent Compoenent
                    </h1>
                    <p>
                        Text <input type="text" ref="txt" />
                         <input type="button" onClick={this.handler} value="Save Data" />
                    </p>
                    <Child/>

            
            </div>);
    }

}

export default Parent;