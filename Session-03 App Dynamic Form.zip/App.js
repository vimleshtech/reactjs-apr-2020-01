import React,{Component} from 'react';


class App extends Component{

  constructor(){
    super();
    this.state ={
        data:[]
    }
  }


  productAdd=()=>{

    var pname = this.refs.pname.value;
    var price = this.refs.price.value;
    var qty = this.refs.qty.value;


    //add data in state object
    var data = this.state.data;
    data.push({pname:pname,price:price,qty:qty});
    //store the data to state
    this.setState({data:data});


    //reset value / clean the form
    this.refs.pname.value="";
    this.refs.price.value="";
    this.refs.qty.value="";


    //print the data 
    console.log(this.state.data);

  }

  render(){

    return(

      <div>
            <h1> Product Form </h1>
            <p>
              Product Name  <input type="text" ref="pname" />
            </p>
            <p>
              Price <input type="text" ref="price"/>
              </p>
            <p>
              Quantity <input type="text" ref="qty" />
            </p>
          <p>
            <input type="button" value="Add Product" onClick={this.productAdd} />
          </p>

          <div>
              {this.state.data.map((row,i)=><div key={i}>

                    {row.pname} | {row.price} | {row.qty} 
                    <input type="button" value="Del" />
                    <input type="button" value="Edit" />
                    
               </div>)}
          </div>


      </div>

    );


    
  }

}

export default App;
